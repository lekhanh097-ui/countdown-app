package com.example.countdowntimerapp.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.countdowntimerapp.MainActivity
import com.example.countdowntimerapp.R
import com.example.countdowntimerapp.data.TimerRepository
import com.example.countdowntimerapp.data.TimerState
import com.example.countdowntimerapp.data.TimerStatus
import com.example.countdowntimerapp.util.TimeFormat
import com.example.countdowntimerapp.widget.CountdownWidgetProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class TimerService : Service() {

    private val repo = TimerRepository
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var tickJob: Job? = null
    private var autoStopJob: Job? = null
    private var endAt = 0L // theo SystemClock.elapsedRealtime()
    private var wakeLock: PowerManager.WakeLock? = null
    private var player: MediaPlayer? = null
    private var alarmPlaying = false
    private lateinit var nm: NotificationManager

    private val vibrator: Vibrator by lazy { obtainVibrator() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        repo.init(this)
        nm = getSystemService(NotificationManager::class.java)
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Bắt buộc gọi startForeground ngay vì service được bật bằng startForegroundService()
        startForegroundCompat(buildNotification())

        when (intent?.action) {
            ACTION_START -> start()
            ACTION_PAUSE -> pause()
            ACTION_TOGGLE ->
                if (repo.state.value.status == TimerStatus.RUNNING) pause() else start()
            ACTION_ADD -> add(intent.getLongExtra(EXTRA_MILLIS, 0L))
            ACTION_SET -> setDuration(intent.getLongExtra(EXTRA_MILLIS, 0L))
            ACTION_RESET -> reset()
            ACTION_STOP_ALARM -> stopAlarmSound()
        }
        settle()
        CountdownWidgetProvider.refreshAll(this)
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- Điều khiển

    private fun start() {
        stopAlarmSound()
        var s = repo.state.value
        if ((s.status == TimerStatus.FINISHED || s.remainingMillis <= 0L) && s.totalMillis > 0L) {
            repo.reset()
        }
        s = repo.state.value
        if (s.remainingMillis <= 0L) return
        repo.setRunning()
        startTicking(s.remainingMillis)
    }

    private fun pause() {
        if (repo.state.value.status != TimerStatus.RUNNING) return
        tickJob?.cancel()
        releaseWakeLock()
        repo.pause(endAt - SystemClock.elapsedRealtime())
    }

    private fun add(ms: Long) {
        if (ms <= 0L) return
        when (repo.state.value.status) {
            TimerStatus.FINISHED -> {
                stopAlarmSound()
                repo.setDuration(ms)
            }
            TimerStatus.RUNNING -> {
                endAt += ms
                repo.addTime(ms)
                acquireWakeLock(endAt - SystemClock.elapsedRealtime())
            }
            else -> repo.addTime(ms)
        }
    }

    private fun setDuration(ms: Long) {
        if (ms <= 0L) return
        tickJob?.cancel()
        releaseWakeLock()
        stopAlarmSound()
        repo.setDuration(ms)
    }

    private fun reset() {
        tickJob?.cancel()
        releaseWakeLock()
        stopAlarmSound()
        repo.reset()
    }

    /** Quyết định service tiếp tục chạy hay dừng sau mỗi lệnh. */
    private fun settle() {
        when (repo.state.value.status) {
            TimerStatus.IDLE -> shutdown()
            TimerStatus.FINISHED -> if (alarmPlaying) updateNotification() else shutdown()
            else -> updateNotification()
        }
    }

    private fun shutdown() {
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------------------------------------------------------------- Vòng đếm

    private fun startTicking(remaining: Long) {
        tickJob?.cancel()
        endAt = SystemClock.elapsedRealtime() + remaining
        acquireWakeLock(remaining)
        tickJob = scope.launch {
            var lastSecond = -1L
            while (isActive) {
                val rem = endAt - SystemClock.elapsedRealtime()
                if (rem <= 0L) {
                    finish()
                    break
                }
                repo.tick(rem)
                val sec = (rem + 999L) / 1000L
                if (sec != lastSecond) { // cập nhật notification/widget mỗi giây
                    lastSecond = sec
                    updateNotification()
                    CountdownWidgetProvider.refreshAll(this@TimerService)
                    repo.persist()
                }
                delay(30L)
            }
        }
    }

    private fun finish() {
        releaseWakeLock()
        repo.finish()
        startAlarmSound()
        startForegroundCompat(buildNotification()) // chuyển sang notification báo thức
        CountdownWidgetProvider.refreshAll(this)
        autoStopJob?.cancel()
        autoStopJob = scope.launch {
            delay(ALARM_MAX_MS)
            stopAlarmSound()
            settle()
        }
    }

    // ---------------------------------------------------------------- Chuông & rung

    private fun startAlarmSound() {
        alarmPlaying = true
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(this@TimerService, uri)
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Không phát được chuông", e)
        }
        startVibration()
    }

    @Suppress("DEPRECATION")
    private fun startVibration() {
        try {
            val effect = VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0)
            val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
            vibrator.vibrate(effect, attrs)
        } catch (e: Exception) {
            Log.e(TAG, "Không rung được", e)
        }
    }

    private fun stopAlarmSound() {
        alarmPlaying = false
        autoStopJob?.cancel()
        player?.let {
            runCatching { it.stop() }
            it.release()
        }
        player = null
        runCatching { vibrator.cancel() }
    }

    @Suppress("DEPRECATION")
    private fun obtainVibrator(): Vibrator =
        if (Build.VERSION.SDK_INT >= 31) {
            getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

    // ---------------------------------------------------------------- WakeLock

    private fun acquireWakeLock(timeoutMs: Long) {
        releaseWakeLock()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "CountdownTimer:tick")
            .apply { acquire(timeoutMs.coerceAtLeast(0L) + 10_000L) }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    // ---------------------------------------------------------------- Notification

    private fun createChannels() {
        nm.createNotificationChannel(
            NotificationChannel(CH_RUNNING, "Đồng hồ đang chạy", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALARM, "Báo hết giờ", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)       // âm thanh do MediaPlayer phát
                enableVibration(false)     // rung do Vibrator điều khiển
            }
        )
    }

    private fun startForegroundCompat(n: Notification) {
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    private fun updateNotification() = nm.notify(NOTIF_ID, buildNotification())

    private fun buildNotification(): Notification {
        val s = repo.state.value
        return if (s.status == TimerStatus.FINISHED && alarmPlaying) buildAlarm() else buildRunning(s)
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun buildRunning(s: TimerState): Notification {
        val running = s.status == TimerStatus.RUNNING
        return NotificationCompat.Builder(this, CH_RUNNING)
            .setSmallIcon(R.drawable.ic_timer)
            .setContentTitle(if (running) "Đang đếm ngược" else "Đã tạm dừng")
            .setContentText(TimeFormat.format(s.remainingMillis, false))
            .setContentIntent(openAppIntent())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setProgress(1000, ((1f - s.progress) * 1000).toInt(), false)
            .addAction(
                if (running) R.drawable.ic_pause else R.drawable.ic_play,
                if (running) "Tạm dừng" else "Tiếp tục",
                pendingIntent(this, ACTION_TOGGLE)
            )
            .addAction(R.drawable.ic_timer, "Đặt lại", pendingIntent(this, ACTION_RESET))
            .build()
    }

    private fun buildAlarm(): Notification {
        val open = openAppIntent()
        return NotificationCompat.Builder(this, CH_ALARM)
            .setSmallIcon(R.drawable.ic_timer)
            .setContentTitle("Hết giờ!")
            .setContentText("Đồng hồ đếm ngược đã về 0")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .addAction(R.drawable.ic_pause, "Tắt chuông", pendingIntent(this, ACTION_STOP_ALARM))
            .build()
    }

    override fun onDestroy() {
        tickJob?.cancel()
        stopAlarmSound()
        releaseWakeLock()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "TimerService"
        private const val CH_RUNNING = "timer_running"
        private const val CH_ALARM = "timer_alarm"
        private const val NOTIF_ID = 1001
        private const val ALARM_MAX_MS = 60_000L

        const val ACTION_START = "com.example.countdowntimerapp.START"
        const val ACTION_PAUSE = "com.example.countdowntimerapp.PAUSE"
        const val ACTION_TOGGLE = "com.example.countdowntimerapp.TOGGLE"
        const val ACTION_RESET = "com.example.countdowntimerapp.RESET"
        const val ACTION_ADD = "com.example.countdowntimerapp.ADD"
        const val ACTION_SET = "com.example.countdowntimerapp.SET"
        const val ACTION_STOP_ALARM = "com.example.countdowntimerapp.STOP_ALARM"
        const val EXTRA_MILLIS = "millis"

        fun send(context: Context, action: String, millis: Long = 0L) {
            val i = Intent(context, TimerService::class.java)
                .setAction(action)
                .putExtra(EXTRA_MILLIS, millis)
            ContextCompat.startForegroundService(context, i)
        }

        fun pendingIntent(context: Context, action: String): PendingIntent =
            PendingIntent.getForegroundService(
                context, action.hashCode(),
                Intent(context, TimerService::class.java).setAction(action),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
    }
}
