package com.example.countdowntimerapp.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LargeFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.countdowntimerapp.TimerViewModel
import com.example.countdowntimerapp.data.TimerState
import com.example.countdowntimerapp.data.TimerStatus
import com.example.countdowntimerapp.util.TimeFormat

private data class Preset(val label: String, val millis: Long)

private val presets = listOf(
    Preset("1 phút", 60_000L),
    Preset("5 phút", 5 * 60_000L),
    Preset("15 phút", 15 * 60_000L),
    Preset("30 phút", 30 * 60_000L),
    Preset("1 giờ", 60 * 60_000L)
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun TimerScreen(vm: TimerViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val showMillis by vm.showMillis.collectAsStateWithLifecycle()
    val running = state.status == TimerStatus.RUNNING

    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("Đếm ngược") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            TimerDisplay(state, showMillis)

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Hiện mili-giây", style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.width(12.dp))
                Switch(checked = showMillis, onCheckedChange = vm::setShowMillis)
            }

            // Điều khiển chính
            Row(
                horizontalArrangement = Arrangement.spacedBy(28.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilledTonalIconButton(
                    onClick = vm::reset,
                    enabled = state.totalMillis > 0L,
                    modifier = Modifier.size(64.dp)
                ) { Icon(Icons.Rounded.Refresh, contentDescription = "Đặt lại") }

                LargeFloatingActionButton(onClick = vm::toggle) {
                    Icon(
                        if (running) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (running) "Tạm dừng" else "Bắt đầu",
                        modifier = Modifier.size(44.dp)
                    )
                }
            }

            // Thêm nhanh
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FilledTonalButton(onClick = { vm.addTime(60_000L) }) {
                    Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(4.dp)); Text("1 phút")
                }
                FilledTonalButton(onClick = { vm.addTime(5 * 60_000L) }) {
                    Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(4.dp)); Text("5 phút")
                }
            }

            // Presets
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Mốc thời gian cài sẵn", style = MaterialTheme.typography.titleMedium)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presets.forEach { p ->
                        FilterChip(
                            selected = state.totalMillis == p.millis,
                            onClick = { vm.setDuration(p.millis) },
                            enabled = !running,
                            label = { Text(p.label) }
                        )
                    }
                }
            }

            ManualInput(enabled = !running, onSet = vm::setDuration)
            Spacer(Modifier.size(24.dp))
        }
    }
}

@Composable
private fun TimerDisplay(state: TimerState, showMillis: Boolean) {
    val finished = state.status == TimerStatus.FINISHED
    val color = if (finished) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
    val text = TimeFormat.format(state.remainingMillis, showMillis)
    val fontSize = when {
        text.length <= 8 -> 52.sp
        text.length <= 9 -> 46.sp
        else -> 34.sp
    }

    Box(modifier = Modifier.size(300.dp), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(
            progress = { state.progress },
            modifier = Modifier.fillMaxSize(),
            color = color,
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
            strokeWidth = 10.dp,
            strokeCap = StrokeCap.Round
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = text,
                maxLines = 1,
                color = if (finished) color else MaterialTheme.colorScheme.onSurface,
                style = TextStyle(
                    fontSize = fontSize,
                    fontWeight = FontWeight.Medium,
                    fontFeatureSettings = "tnum" // chữ số đều nhau, không bị nhảy
                )
            )
            Text(
                text = when (state.status) {
                    TimerStatus.IDLE -> "Sẵn sàng"
                    TimerStatus.RUNNING -> "Đang chạy"
                    TimerStatus.PAUSED -> "Tạm dừng"
                    TimerStatus.FINISHED -> "Hết giờ!"
                },
                style = MaterialTheme.typography.titleMedium,
                color = color
            )
        }
    }
}

@Composable
private fun ManualInput(enabled: Boolean, onSet: (Long) -> Unit) {
    var h by rememberSaveable { mutableStateOf("") }
    var m by rememberSaveable { mutableStateOf("") }
    var s by rememberSaveable { mutableStateOf("") }
    val focus = LocalFocusManager.current

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Nhập thủ công", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TimeField("Giờ", h, enabled, ImeAction.Next, Modifier.weight(1f)) { h = it }
                TimeField("Phút", m, enabled, ImeAction.Next, Modifier.weight(1f)) { m = it }
                TimeField("Giây", s, enabled, ImeAction.Done, Modifier.weight(1f)) { s = it }
            }
            Button(
                modifier = Modifier.fillMaxWidth(),
                enabled = enabled,
                onClick = {
                    val seconds = (h.toLongOrNull() ?: 0L) * 3600 +
                        (m.toLongOrNull() ?: 0L) * 60 + (s.toLongOrNull() ?: 0L)
                    if (seconds > 0L) {
                        onSet(seconds * 1000L)
                        focus.clearFocus()
                    }
                }
            ) { Text("Đặt thời gian") }
        }
    }
}

@Composable
private fun TimeField(
    label: String,
    value: String,
    enabled: Boolean,
    ime: ImeAction,
    modifier: Modifier,
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter(Char::isDigit).take(2)) },
        label = { Text(label) },
        enabled = enabled,
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ime),
        modifier = modifier
    )
}
