package com.example.countdowntimerapp.util

import java.util.Locale

object TimeFormat {
    /**
     * showMillis = false -> HH:MM:SS (làm tròn lên để 00:00:01 hiển thị đến giây cuối)
     * showMillis = true  -> MM:SS.mmm (hoặc HH:MM:SS.mmm nếu còn >= 1 giờ)
     */
    fun format(ms: Long, showMillis: Boolean): String {
        val v = ms.coerceAtLeast(0L)
        val t = if (showMillis) v else ((v + 999L) / 1000L) * 1000L
        val h = t / 3_600_000L
        val m = (t / 60_000L) % 60
        val s = (t / 1000L) % 60
        val milli = t % 1000L
        return when {
            !showMillis -> String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
            h > 0 -> String.format(Locale.US, "%02d:%02d:%02d.%03d", h, m, s, milli)
            else -> String.format(Locale.US, "%02d:%02d.%03d", m, s, milli)
        }
    }
}
