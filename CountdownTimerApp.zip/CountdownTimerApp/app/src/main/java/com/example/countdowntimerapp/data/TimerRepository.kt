package com.example.countdowntimerapp.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class TimerStatus { IDLE, RUNNING, PAUSED, FINISHED }

data class TimerState(
    val totalMillis: Long = 0L,
    val remainingMillis: Long = 0L,
    val status: TimerStatus = TimerStatus.IDLE
) {
    val progress: Float
        get() = if (totalMillis <= 0L) 0f
        else (remainingMillis.toFloat() / totalMillis).coerceIn(0f, 1f)
}

/**
 * Nguồn dữ liệu duy nhất (single source of truth) dùng chung cho
 * ViewModel, Service và Widget. Trạng thái được lưu vào SharedPreferences
 * để widget vẫn hiển thị đúng khi process bị khởi động lại.
 */
object TimerRepository {
    private const val PREFS = "timer_state"
    private val _state = MutableStateFlow(TimerState())
    val state: StateFlow<TimerState> = _state.asStateFlow()
    private var prefs: SharedPreferences? = null

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = p
        var status = runCatching { TimerStatus.valueOf(p.getString("status", "IDLE")!!) }
            .getOrDefault(TimerStatus.IDLE)
        // Process vừa khởi động mà trạng thái là RUNNING => service đã chết => coi như tạm dừng
        if (status == TimerStatus.RUNNING) status = TimerStatus.PAUSED
        _state.value = TimerState(p.getLong("total", 0L), p.getLong("remaining", 0L), status)
    }

    fun setDuration(ms: Long) = mutate { TimerState(ms, ms, TimerStatus.IDLE) }
    fun addTime(ms: Long) = mutate {
        it.copy(totalMillis = it.totalMillis + ms, remainingMillis = it.remainingMillis + ms)
    }
    fun reset() = mutate { it.copy(remainingMillis = it.totalMillis, status = TimerStatus.IDLE) }
    fun setRunning() = mutate { it.copy(status = TimerStatus.RUNNING) }
    fun pause(remaining: Long) = mutate {
        it.copy(remainingMillis = remaining.coerceAtLeast(0L), status = TimerStatus.PAUSED)
    }
    fun finish() = mutate { it.copy(remainingMillis = 0L, status = TimerStatus.FINISHED) }

    /** Gọi mỗi ~30ms từ service, không ghi đĩa. */
    fun tick(remaining: Long) {
        _state.update { it.copy(remainingMillis = remaining, status = TimerStatus.RUNNING) }
    }

    fun persist() {
        val s = _state.value
        prefs?.edit()
            ?.putLong("total", s.totalMillis)
            ?.putLong("remaining", s.remainingMillis)
            ?.putString("status", s.status.name)
            ?.apply()
    }

    private fun mutate(f: (TimerState) -> TimerState) {
        _state.update(f)
        persist()
    }
}
