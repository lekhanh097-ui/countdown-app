package com.example.countdowntimerapp.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.countdowntimerapp.MainActivity
import com.example.countdowntimerapp.R
import com.example.countdowntimerapp.data.TimerRepository
import com.example.countdowntimerapp.data.TimerStatus
import com.example.countdowntimerapp.service.TimerService
import com.example.countdowntimerapp.util.TimeFormat

class CountdownWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val views = buildViews(context)
        ids.forEach { manager.updateAppWidget(it, views) }
    }

    companion object {
        /** Gọi từ Service / ViewModel mỗi khi trạng thái thay đổi. */
        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, CountdownWidgetProvider::class.java))
            if (ids.isEmpty()) return
            manager.updateAppWidget(ids, buildViews(context))
        }

        private fun buildViews(context: Context): RemoteViews {
            TimerRepository.init(context)
            val s = TimerRepository.state.value
            val running = s.status == TimerStatus.RUNNING

            val views = RemoteViews(context.packageName, R.layout.widget_countdown)
            views.setTextViewText(R.id.widgetTime, TimeFormat.format(s.remainingMillis, false))
            views.setTextViewText(
                R.id.widgetLabel,
                when (s.status) {
                    TimerStatus.IDLE -> "Sẵn sàng"
                    TimerStatus.RUNNING -> "Đang chạy"
                    TimerStatus.PAUSED -> "Tạm dừng"
                    TimerStatus.FINISHED -> "Hết giờ!"
                }
            )
            views.setImageViewResource(
                R.id.widgetToggle,
                if (running) R.drawable.ic_pause else R.drawable.ic_play
            )

            val openApp = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            views.setOnClickPendingIntent(R.id.widgetRoot, openApp)

            // Chưa đặt giờ -> nút mở app để chọn giờ; đã có giờ -> Play/Pause trực tiếp
            val canStart = running || s.totalMillis > 0L
            views.setOnClickPendingIntent(
                R.id.widgetToggle,
                if (canStart) TimerService.pendingIntent(context, TimerService.ACTION_TOGGLE) else openApp
            )
            return views
        }
    }
}
