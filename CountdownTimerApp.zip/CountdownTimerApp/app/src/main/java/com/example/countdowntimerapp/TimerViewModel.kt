package com.example.countdowntimerapp

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.countdowntimerapp.data.TimerRepository
import com.example.countdowntimerapp.data.TimerState
import com.example.countdowntimerapp.data.TimerStatus
import com.example.countdowntimerapp.service.TimerService
import com.example.countdowntimerapp.widget.CountdownWidgetProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class TimerViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx = app.applicationContext
    private val repo = TimerRepository

    val state: StateFlow<TimerState> = repo.state

    private val _showMillis = MutableStateFlow(false)
    val showMillis: StateFlow<Boolean> = _showMillis.asStateFlow()

    init {
        repo.init(ctx)
        CountdownWidgetProvider.refreshAll(ctx)
    }

    fun setShowMillis(value: Boolean) { _showMillis.value = value }

    /** Khi không IDLE, service đang giữ trạng thái -> gửi lệnh qua service. */
    private val serviceActive get() = state.value.status != TimerStatus.IDLE

    fun toggle() {
        val s = state.value
        if (s.status != TimerStatus.RUNNING && s.totalMillis <= 0L) return
        TimerService.send(ctx, TimerService.ACTION_TOGGLE)
    }

    fun reset() {
        if (serviceActive) TimerService.send(ctx, TimerService.ACTION_RESET)
        else { repo.reset(); CountdownWidgetProvider.refreshAll(ctx) }
    }

    fun setDuration(ms: Long) {
        if (ms <= 0L) return
        if (serviceActive) TimerService.send(ctx, TimerService.ACTION_SET, ms)
        else { repo.setDuration(ms); CountdownWidgetProvider.refreshAll(ctx) }
    }

    fun addTime(ms: Long) {
        if (serviceActive) TimerService.send(ctx, TimerService.ACTION_ADD, ms)
        else { repo.addTime(ms); CountdownWidgetProvider.refreshAll(ctx) }
    }
}
